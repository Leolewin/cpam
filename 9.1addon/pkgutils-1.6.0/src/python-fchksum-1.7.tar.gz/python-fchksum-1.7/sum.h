#ifndef _SUM_H__
#define _SUM_H__

int bsd_sum_stream (int fd, unsigned long *res, chksum_size_t *size, CallbackInfo *cbinfo);
int sysv_sum_stream (int fd, unsigned long *res, chksum_size_t *size, CallbackInfo *cbinfo);

#endif

