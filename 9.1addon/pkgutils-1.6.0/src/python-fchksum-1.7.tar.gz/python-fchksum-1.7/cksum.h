#ifndef _CKSUM_H__
#define _CKSUM_H__

int cksum_stream (int fd, unsigned long *res, chksum_size_t *size, CallbackInfo *cbinfo);

#endif
